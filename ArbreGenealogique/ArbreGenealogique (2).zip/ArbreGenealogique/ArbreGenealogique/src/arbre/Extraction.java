package arbre;

import java.io.*;
import java.util.*;

import org.apache.poi.ss.usermodel.*;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.time.*;

public class Extraction {
    public static void main(String[] args) {
        Extraction obj = new Extraction();
        obj.ExcelExtraction();
    }

    public String ExcelExtraction() {
        // Le chemin du fichier Excel
        String excelFile = "C:/Users/lachk/Downloads/ArbreGenealogique/ArbreGenealogique/src/familles.xlsx";
        try (FileInputStream fis = new FileInputStream(excelFile); Workbook workbook = WorkbookFactory.create(fis)) {
            
            // Obtenir la première feuille de calcul
            Sheet sheet = workbook.getSheetAt(0);

            // Identifier les colonnes des informations personnelles
            int idc = 0; // Colonne du nom
            int nomc = 1; // Colonne du prénom
            int prenomc = 2; // Colonne de l'adresse e-mail
            int dateDeNaissancec = 3;
            int nationalitec = 4;
            int sexec = 5;
            int merec = 6;
            int perec = 7;
            List<Personne> personnes = new ArrayList<>();

            // Parcourir les lignes de la feuille de calcul
            for (int rowIndex = 1; rowIndex < sheet.getPhysicalNumberOfRows(); rowIndex++) {
                Row row = sheet.getRow(rowIndex);
                if (row == null) continue;

                DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");

                // Extraire les données de la personne
                Personne personneajoute = new Personne();

                // Gérer l'extraction des différentes cellules
                Cell cell = row.getCell(idc);
                if (cell != null && cell.getCellType() == CellType.NUMERIC) {
                    int id = (int) cell.getNumericCellValue();
                    personneajoute.setId(id);
                }

                cell = row.getCell(nomc);
                if (cell != null && cell.getCellType() == CellType.STRING) {
                    String nom = cell.getStringCellValue();
                    personneajoute.setNom(nom);
                }

                cell = row.getCell(prenomc);
                if (cell != null && cell.getCellType() == CellType.STRING) {
                    String prenom = cell.getStringCellValue();
                    personneajoute.setPrenom(prenom);
                }

                cell = row.getCell(dateDeNaissancec);
                if (cell != null && cell.getCellType() == CellType.STRING) {
                    String dateDN = cell.getStringCellValue();
                    LocalDate dateDeNaissance = null;
                    try {
                        // Convertir la chaîne de caractères en LocalDate
                        dateDeNaissance = LocalDate.parse(dateDN, formatter);
                        System.out.println("Date convertie (java.time.LocalDate) : " + dateDeNaissance);
                    } catch (DateTimeParseException e) {
                        System.err.println("Erreur de format de date : " + e.getMessage());
                    }
                    personneajoute.setDateDeNaissance(dateDeNaissance);
                    personneajoute.setDateDeDeces(dateDeNaissance);
                }

                cell = row.getCell(nationalitec);
                if (cell != null && cell.getCellType() == CellType.STRING) {
                    String nationalite = cell.getStringCellValue();
                    personneajoute.setNationalite(nationalite);
                }

                cell = row.getCell(sexec);
                if (cell != null && cell.getCellType() == CellType.STRING) {
                    String sexe = cell.getStringCellValue();
                    personneajoute.setSexe(sexe);
                }

                cell = row.getCell(perec);
                if (cell != null && cell.getCellType() == CellType.NUMERIC) {
                    int pereid = (int) cell.getNumericCellValue();
                    for (Personne personne : personnes) {
                        if (personne.getId() == pereid) {
                            personneajoute.setPere(personne);
                        }
                    }
                }

                cell = row.getCell(merec);
                if (cell != null && cell.getCellType() == CellType.NUMERIC) {
                    int mereid = (int) cell.getNumericCellValue();
                    for (Personne personne : personnes) {
                        if (personne.getId() == mereid) {
                            personneajoute.setMere(personne);
                        }
                    }
                }

                List<Personne> enfants = new ArrayList<>();
                personneajoute.setEnfants(enfants);

                personnes.add(personneajoute);

                System.out.println(personneajoute);
                
                /*
                for (Personne personne : personnes) {
                    if (personne.getId() == personneajoute.getPere() != null ? personneajoute.getPere().getId() : -1) {
                        personne.ajoutEnfants(personneajoute);
                    }
                    if (personne.getId() == personneajoute.getMere() != null ? personneajoute.getMere().getId() : -1) {
                        personne.ajoutEnfants(personneajoute);
                    }
                }
                */
                
                
            }
            System.out.println("Reading File Completed.");

        } catch (IOException e) {
            System.out.println("ExcelExtraction catch block");
            e.printStackTrace();
        }
        return "test";
    }
}
